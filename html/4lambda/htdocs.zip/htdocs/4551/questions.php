<?php

$question1 = array(
    "qAnswer 1",
    "qAnswer 2",
    "qAnswer 3",
    "qAnswer 4"
);

$question2 = array(
    "bAnswer 1" => 1,
    "bAnswer 2" => 2,
    "bAnswer 3" => 3,
    "bAnswer 4" => 4
);

$question3 = array(
    "Answer 1" => 1,
    "Answer 2" => 2,
    "Answer 3" => 3,
    "Answer 4" => 4
);

$question4 = array(
    "Answer 1" => 1,
    "Answer 2" => 2,
    "Answer 3" => 3,
    "Answer 4" => 4
);

$question5 = array(
    "Answer 1" => 1,
    "Answer 2" => 2,
    "Answer 3" => 3,
    "Answer 4" => 4
);

$questions = array(
    $question1,
    $question2,
    $question3,
    $question4,
    $question5
);